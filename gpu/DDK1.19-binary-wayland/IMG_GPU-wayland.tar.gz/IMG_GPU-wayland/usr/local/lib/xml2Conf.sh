#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/local/lib"
XML2_LIBS="-lxml2 -L/home/clement/sft-riscvpi-freedom-u-sdk/soft_3rdpart/IMG_GPU/linux/rogue_1.19/binary_sf_7110_wayland_release/target_riscv64/usr/local/lib -lz     -lm "
XML2_INCLUDEDIR="-I/usr/local/include/libxml2"
MODULE_VERSION="xml2-2.9.13"

